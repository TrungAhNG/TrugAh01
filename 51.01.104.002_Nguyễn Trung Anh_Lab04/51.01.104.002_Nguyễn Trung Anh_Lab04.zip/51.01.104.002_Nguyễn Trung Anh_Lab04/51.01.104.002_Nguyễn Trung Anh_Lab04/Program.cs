﻿using System;
using System.Collections.Generic;
using System.Linq;
namespace Lab04{
    public interface IEntity    {
        string Id { get; }
    }
    public class DuplicateProductException : Exception    {
        public DuplicateProductException(string message) : base(message) { }
    }
    public class ProductNotFoundException : Exception    {
        public ProductNotFoundException(string message) : base(message) { }
    }
    public class Product : IEntity    {
        public string Id => MaSP; // Implement IEntity.Id
        public string MaSP { get; set; }
        public string TenSP { get; set; }
        private decimal _price;
        public decimal Price
        {
            get => _price;
            set
            {
                if (value < 0) throw new ArgumentException("Đơn giá không được âm.");
                _price = value;
            }
        }
        private int _quantity;
        public int Quantity        {
            get => _quantity;
            set            {
                if (value < 0) throw new ArgumentException("Số lượng không được âm.");
                _quantity = value;
            }
        }
        public Product(string maSP, string tenSP, decimal price, int quantity)        {
            if (string.IsNullOrWhiteSpace(maSP))
                throw new ArgumentException("Mã sản phẩm không được rỗng.");
            MaSP = maSP;
            TenSP = tenSP;
            Price = price;
            Quantity = quantity;
        }
        public override string ToString()        {
            return $"Mã SP: {MaSP,-10} | Tên SP: {TenSP,-20} | Đơn giá: {Price,10:N0} | Số lượng: {Quantity,-5}";
        }
    }
    public class Repository<T> where T : IEntity    {
        private readonly List<T> _items = new List<T>();
        public void Add(T item)        {
            if (_items.Any(i => i.Id.Equals(item.Id, StringComparison.OrdinalIgnoreCase)))            {
                throw new DuplicateProductException($"Đã tồn tại đối tượng với mã '{item.Id}'.");
            }
            _items.Add(item);
        }
        public void Remove(string id)        {
            var item = FindById(id);
            if (item == null)            {
                throw new ProductNotFoundException($"Không tìm thấy đối tượng với mã '{id}' để xóa.");
            }
            _items.Remove(item);
        }
        public T FindById(string id)        {
            return _items.FirstOrDefault(i => i.Id.Equals(id, StringComparison.OrdinalIgnoreCase));
        }
        public IEnumerable<T> Find(Func<T, bool> predicate)        {
            return _items.Where(predicate);
        }
        public IEnumerable<T> GetAll()        {
            return _items.AsReadOnly();
        }
    }
    public class ProductService    {
        private readonly Repository<Product> _repo = new Repository<Product>();
        public event Action<Product> OnProductAdded;
        public event Action<string> OnProductRemoved;
        public void AddProduct(Product product)        {
            _repo.Add(product);
            OnProductAdded?.Invoke(product); // Phát event
        }
        public void RemoveProduct(string maSP)        {
            _repo.Remove(maSP);
            OnProductRemoved?.Invoke(maSP); // Phát event
        }
        public IEnumerable<Product> GetAll() => _repo.GetAll();
        public Product FindById(string maSP) => _repo.FindById(maSP);
        public IEnumerable<Product> SearchByName(string keyword)        {
            return _repo.Find(p => p.TenSP.Contains(keyword, StringComparison.OrdinalIgnoreCase));
        }
        public IEnumerable<Product> FilterByPrice(decimal minPrice, decimal maxPrice)        {
            return _repo.Find(p => p.Price >= minPrice && p.Price <= maxPrice);
        }
        public decimal CalculateTotalInventoryValue()        {
            return _repo.GetAll().Sum(p => p.Price * p.Quantity);
        }
    }
    class Program    {
        static void Main(string[] args)        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            ProductService service = new ProductService();
            service.OnProductAdded += product =>
                Console.WriteLine($"[Event] Đã thêm thành công sản phẩm: {product.TenSP}");
            service.OnProductRemoved += maSP =>
                Console.WriteLine($"[Event] Đã xóa thành công sản phẩm mã: {maSP}");
            int choice = -1;
            do            {
                Console.WriteLine("\n===== PRODUCT MANAGER =====");
                Console.WriteLine("1. Thêm sản phẩm");
                Console.WriteLine("2. Xuất danh sách");
                Console.WriteLine("3. Tìm theo mã");
                Console.WriteLine("4. Tìm theo tên");
                Console.WriteLine("5. Lọc theo khoảng giá");
                Console.WriteLine("6. Xóa sản phẩm");
                Console.WriteLine("7. Tính tổng giá trị kho");
                Console.WriteLine("0. Thoát");
                choice = ReadInt("Chọn chức năng (0-7): ");
                try                {
                    switch (choice)                    {
                        case 1:
                            AddProductUI(service);
                            break;
                        case 2:
                            PrintList(service.GetAll());
                            break;
                        case 3:
                            string maTim = ReadString("Nhập mã SP cần tìm: ");
                            var pMa = service.FindById(maTim);
                            if (pMa != null) Console.WriteLine(pMa);
                            else Console.WriteLine("Không tìm thấy sản phẩm!");
                            break;
                        case 4:
                            string keyword = ReadString("Nhập từ khóa tên SP: ");
                            PrintList(service.SearchByName(keyword));
                            break;
                        case 5:
                            decimal min = ReadDecimal("Nhập giá tối thiểu: ");
                            decimal max = ReadDecimal("Nhập giá tối đa: ");
                            PrintList(service.FilterByPrice(min, max));
                            break;
                        case 6:
                            string maXoa = ReadString("Nhập mã SP cần xóa: ");
                            service.RemoveProduct(maXoa);
                            break;
                        case 7:
                            Console.WriteLine($"Tổng giá trị kho: {service.CalculateTotalInventoryValue():N0}");
                            break;
                        case 0:
                            Console.WriteLine("Đang thoát chương trình...");
                            break;
                        default:
                            Console.WriteLine("Lựa chọn không hợp lệ!");
                            break;
                    }
                }
                catch (DuplicateProductException ex)                {
                    Console.WriteLine($"[Lỗi Trùng Lặp] {ex.Message}");
                }
                catch (ProductNotFoundException ex)                {
                    Console.WriteLine($"[Lỗi Dữ Liệu] {ex.Message}");
                }
                catch (ArgumentException ex)                {
                    Console.WriteLine($"[Lỗi Nhập Liệu] {ex.Message}");
                }
                catch (Exception ex)                {
                    Console.WriteLine($"[Lỗi Hệ Thống] {ex.Message}");
                }

            } while (choice != 0);
        }
        static void AddProductUI(ProductService service)        {
            string ma = ReadString("Nhập mã SP: ");
            string ten = ReadString("Nhập tên SP: ");
            decimal gia = ReadDecimal("Nhập đơn giá: ");
            int sl = ReadInt("Nhập số lượng: ");

            Product p = new Product(ma, ten, gia, sl);
            service.AddProduct(p);
        }
        static void PrintList(IEnumerable<Product> list)        {
            if (!list.Any())            {
                Console.WriteLine("Danh sách trống!");
                return;
            }
            foreach (var item in list)            {
                Console.WriteLine(item);
            }
        }
        static string ReadString(string message)        {
            Console.Write(message);
            return Console.ReadLine()?.Trim() ?? string.Empty;
        }
        static int ReadInt(string message)        {
            while (true)            {
                Console.Write(message);
                if (int.TryParse(Console.ReadLine(), out int result))
                    return result;
                Console.WriteLine("Vui lòng nhập một số nguyên hợp lệ.");
            }
        }
        static decimal ReadDecimal(string message)        {
            while (true)            {
                Console.Write(message);
                if (decimal.TryParse(Console.ReadLine(), out decimal result))
                    return result;
                Console.WriteLine("Vui lòng nhập một số thực hợp lệ.");
            }
        }
    }
}