using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace CourseRegistrationApp
{
    public partial class Form1 : Form
    {
        // Lớp cấu trúc dữ liệu khóa học
        public class Course
        {
            public string Name { get; set; }
            public decimal Price { get; set; }

            public override string ToString()
            {
                return Name;
            }
        }

        public Form1()
        {
            InitializeComponent();

            // Gắn sự kiện (Event) 
            this.Load += Form1_Load;
            btnDangKy.Click += btnDangKy_Click;
            btnLamMoi.Click += btnLamMoi_Click;
            btnThoat.Click += btnThoat_Click;

            // Gắn sự kiện tự động tính lại tiền khi thay đổi khóa học hoặc số tháng
            cboKhoaHoc.SelectedIndexChanged += UpdateTongTien;
            numSoThang.ValueChanged += UpdateTongTien;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Thiết lập số tháng tối thiểu là 1, tối đa là 12
            numSoThang.Minimum = 1;
            numSoThang.Maximum = 12;
            numSoThang.Value = 1;

            // Mặc định hình thức Online
            radOnline.Checked = true;

            // Nạp danh sách khóa học và học phí
            List<Course> courses = new List<Course>()
            {
                new Course { Name = "Lập trình cơ bản - nâng cao", Price = 800000 },
                new Course { Name = "Cơ sở dữ liệu cơ bản", Price = 600000 },
                new Course { Name = "Cấu trúc dữ liệu", Price = 750000 },
                new Course { Name = "Phân tích thiết kế & Giải thuật", Price = 800000 }
            };

            cboKhoaHoc.DataSource = courses;

            // Chọn mặc định khóa học đầu tiên
            cboKhoaHoc.SelectedIndex = 0;

            // Cập nhật hiển thị tổng tiền ban đầu
            UpdateTongTien(null, null);
        }

        private void UpdateTongTien(object sender, EventArgs e)
        {
            if (cboKhoaHoc.SelectedItem is Course selectedCourse)
            {
                // Tính tổng học phí = học phí một tháng x số tháng
                decimal tongTien = selectedCourse.Price * numSoThang.Value;
                lblTongTien.Text = $"Tổng học phí: {tongTien:N0} VNĐ";
            }
        }

        private void btnDangKy_Click(object sender, EventArgs e)
        {
            // Kiểm tra dữ liệu đầu vào
            if (string.IsNullOrWhiteSpace(txtHoTen.Text))
            {
                MessageBox.Show("Họ tên không được để trống!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtHoTen.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(txtSoDienThoai.Text))
            {
                MessageBox.Show("Số điện thoại không được để trống!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtSoDienThoai.Focus();
                return;
            }

            if (cboKhoaHoc.SelectedIndex == -1)
            {
                MessageBox.Show("Vui lòng chọn khóa học!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Lấy thông tin
            Course selectedCourse = (Course)cboKhoaHoc.SelectedItem;
            decimal tongTien = selectedCourse.Price * numSoThang.Value;
            string hinhThuc = radOnline.Checked ? "Online" : "Trực tiếp (Offline)";
            string nhanEmail = chkNhanEmail.Checked ? "Có" : "Không";

            // Hiển thị phiếu đăng ký
            string message = "--- PHIẾU ĐĂNG KÝ ---\n\n";
            message += $"Họ tên: {txtHoTen.Text.Trim()}\n";
            message += $"Số điện thoại: {txtSoDienThoai.Text.Trim()}\n";
            message += $"Ngày sinh: {dtpNgaySinh.Value:dd/MM/yyyy}\n";
            message += $"Khóa học: {selectedCourse.Name}\n";
            message += $"Hình thức: {hinhThuc}\n";
            message += $"Số tháng: {numSoThang.Value}\n";
            message += $"Tổng tiền: {tongTien:N0} VNĐ\n";
            message += $"Nhận email: {nhanEmail}";

            MessageBox.Show(message, "Đăng ký thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            // Xóa dữ liệu và khôi phục mặc định
            txtHoTen.Clear();
            txtSoDienThoai.Clear();
            dtpNgaySinh.Value = DateTime.Now;
            chkNhanEmail.Checked = false;

            cboKhoaHoc.SelectedIndex = 0;
            radOnline.Checked = true;
            numSoThang.Value = 1;

            // Đưa con trỏ về ô họ tên
            txtHoTen.Focus();
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            // Hiển thị hộp thoại xác nhận
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn thoát chương trình?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void cboKhoaHoc_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}