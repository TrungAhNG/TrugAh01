﻿namespace CourseRegistrationApp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            chkNhanEmail = new CheckBox();
            label3 = new Label();
            dtpNgaySinh = new DateTimePicker();
            label2 = new Label();
            label1 = new Label();
            txtSoDienThoai = new TextBox();
            txtHoTen = new TextBox();
            groupBox2 = new GroupBox();
            lblTongTien = new Label();
            label6 = new Label();
            numSoThang = new NumericUpDown();
            label5 = new Label();
            radOffline = new RadioButton();
            radOnline = new RadioButton();
            label4 = new Label();
            cboKhoaHoc = new ComboBox();
            btnDangKy = new Button();
            btnLamMoi = new Button();
            btnThoat = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)numSoThang).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(chkNhanEmail);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(dtpNgaySinh);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(txtSoDienThoai);
            groupBox1.Controls.Add(txtHoTen);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(387, 156);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Thông tin học viên";
            // 
            // chkNhanEmail
            // 
            chkNhanEmail.AutoSize = true;
            chkNhanEmail.Location = new Point(6, 122);
            chkNhanEmail.Name = "chkNhanEmail";
            chkNhanEmail.Size = new Size(107, 24);
            chkNhanEmail.TabIndex = 6;
            chkNhanEmail.Text = "Nhận Email";
            chkNhanEmail.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(6, 99);
            label3.Name = "label3";
            label3.Size = new Size(85, 20);
            label3.TabIndex = 5;
            label3.Text = "Ngày sinh : ";
            // 
            // dtpNgaySinh
            // 
            dtpNgaySinh.Location = new Point(120, 92);
            dtpNgaySinh.Name = "dtpNgaySinh";
            dtpNgaySinh.Size = new Size(250, 27);
            dtpNgaySinh.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(6, 66);
            label2.Name = "label2";
            label2.Size = new Size(108, 20);
            label2.TabIndex = 3;
            label2.Text = "Số điện thoại : ";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(6, 33);
            label1.Name = "label1";
            label1.Size = new Size(84, 20);
            label1.TabIndex = 2;
            label1.Text = "Họ và tên : ";
            // 
            // txtSoDienThoai
            // 
            txtSoDienThoai.Location = new Point(120, 59);
            txtSoDienThoai.Name = "txtSoDienThoai";
            txtSoDienThoai.Size = new Size(250, 27);
            txtSoDienThoai.TabIndex = 1;
            // 
            // txtHoTen
            // 
            txtHoTen.Location = new Point(120, 26);
            txtHoTen.Name = "txtHoTen";
            txtHoTen.Size = new Size(250, 27);
            txtHoTen.TabIndex = 0;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(lblTongTien);
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(numSoThang);
            groupBox2.Controls.Add(label5);
            groupBox2.Controls.Add(radOffline);
            groupBox2.Controls.Add(radOnline);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(cboKhoaHoc);
            groupBox2.Location = new Point(12, 174);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(387, 164);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "Thông tin khóa học";
            // 
            // lblTongTien
            // 
            lblTongTien.AutoSize = true;
            lblTongTien.Location = new Point(6, 130);
            lblTongTien.Name = "lblTongTien";
            lblTongTien.Size = new Size(83, 20);
            lblTongTien.TabIndex = 12;
            lblTongTien.Text = "Tổng tiền : ";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(6, 97);
            label6.Name = "label6";
            label6.Size = new Size(103, 20);
            label6.TabIndex = 11;
            label6.Text = "Số tháng học :";
            // 
            // numSoThang
            // 
            numSoThang.Location = new Point(147, 90);
            numSoThang.Name = "numSoThang";
            numSoThang.Size = new Size(223, 27);
            numSoThang.TabIndex = 7;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(6, 62);
            label5.Name = "label5";
            label5.Size = new Size(112, 20);
            label5.TabIndex = 10;
            label5.Text = "Hình thức học : ";
            // 
            // radOffline
            // 
            radOffline.AutoSize = true;
            radOffline.Location = new Point(226, 60);
            radOffline.Name = "radOffline";
            radOffline.Size = new Size(75, 24);
            radOffline.TabIndex = 9;
            radOffline.TabStop = true;
            radOffline.Text = "Offline";
            radOffline.UseVisualStyleBackColor = true;
            // 
            // radOnline
            // 
            radOnline.AutoSize = true;
            radOnline.Location = new Point(147, 60);
            radOnline.Name = "radOnline";
            radOnline.Size = new Size(73, 24);
            radOnline.TabIndex = 8;
            radOnline.TabStop = true;
            radOnline.Text = "Online";
            radOnline.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(6, 34);
            label4.Name = "label4";
            label4.Size = new Size(135, 20);
            label4.TabIndex = 7;
            label4.Text = "Combo Khóa học : ";
            // 
            // cboKhoaHoc
            // 
            cboKhoaHoc.FormattingEnabled = true;
            cboKhoaHoc.Location = new Point(147, 26);
            cboKhoaHoc.Name = "cboKhoaHoc";
            cboKhoaHoc.Size = new Size(223, 28);
            cboKhoaHoc.TabIndex = 0;
            cboKhoaHoc.SelectedIndexChanged += cboKhoaHoc_SelectedIndexChanged;
            // 
            // btnDangKy
            // 
            btnDangKy.Location = new Point(12, 344);
            btnDangKy.Name = "btnDangKy";
            btnDangKy.Size = new Size(94, 29);
            btnDangKy.TabIndex = 2;
            btnDangKy.Text = "Đăng ký";
            btnDangKy.UseVisualStyleBackColor = true;
            // 
            // btnLamMoi
            // 
            btnLamMoi.Location = new Point(112, 344);
            btnLamMoi.Name = "btnLamMoi";
            btnLamMoi.Size = new Size(94, 29);
            btnLamMoi.TabIndex = 3;
            btnLamMoi.Text = "Làm mới";
            btnLamMoi.UseVisualStyleBackColor = true;
            // 
            // btnThoat
            // 
            btnThoat.Location = new Point(212, 344);
            btnThoat.Name = "btnThoat";
            btnThoat.Size = new Size(94, 29);
            btnThoat.TabIndex = 4;
            btnThoat.Text = "Thoát";
            btnThoat.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(420, 450);
            Controls.Add(btnThoat);
            Controls.Add(btnLamMoi);
            Controls.Add(btnDangKy);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "ĐĂNG KÝ KHÓA HỌC";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)numSoThang).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private Label label2;
        private Label label1;
        private TextBox txtSoDienThoai;
        private TextBox txtHoTen;
        private CheckBox chkNhanEmail;
        private Label label3;
        private DateTimePicker dtpNgaySinh;
        private RadioButton radOffline;
        private RadioButton radOnline;
        private Label label4;
        private ComboBox cboKhoaHoc;
        private Label label5;
        private Label lblTongTien;
        private Label label6;
        private NumericUpDown numSoThang;
        private Button btnDangKy;
        private Button btnLamMoi;
        private Button btnThoat;
    }
}
