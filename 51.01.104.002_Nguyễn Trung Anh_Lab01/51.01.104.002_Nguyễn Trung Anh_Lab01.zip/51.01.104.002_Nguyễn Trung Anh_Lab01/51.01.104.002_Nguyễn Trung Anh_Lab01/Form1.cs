using System;
using System.Windows.Forms;
namespace _51._01._104._002_Nguyễn_Trung_Anh_Lab01 {
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            btnHienthi.Text = "Hiển thị";
            btnXoa.Text = "Xóa";
            btnThoat.Text = "Thoát";
            this.Load += Form1_Load;
            btnHienthi.Click += BtnHienthi_Click;
            btnXoa.Click += BtnXoa_Click;
            btnThoat.Click += BtnThoat_Click;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            cboKhoa.Items.Add("Công nghệ Thông tin");
            cboKhoa.Items.Add("Sư phạm Tin học");
            cboKhoa.Items.Add("Công nghệ Giáo dục");
            this.StartPosition = FormStartPosition.CenterScreen;
        }
        private void BtnHienthi_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtHoTen.Text))
            {
                MessageBox.Show("Vui lòng nhập họ tên!", "Lỗi nhập liệu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtHoTen.Focus();
                return;
            }
            if (!int.TryParse(txtNamSinh.Text, out int namSinh))
            {
                MessageBox.Show("Năm sinh phải là số nguyên!", "Lỗi nhập liệu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNamSinh.Focus();
                return;
            }
            int namHienTai = DateTime.Now.Year;
            if (namSinh < 1900 || namSinh > namHienTai)
            {
                MessageBox.Show($"Năm sinh phải nằm trong khoảng từ 1900 đến {namHienTai}!", "Lỗi nhập liệu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtNamSinh.Focus();
                return;
            }
            if (string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                MessageBox.Show("Vui lòng nhập email!", "Lỗi nhập liệu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtEmail.Focus();
                return;
            }
            if (!radNam.Checked && !radNu.Checked)
            {
                MessageBox.Show("Vui lòng chọn giới tính!", "Lỗi nhập liệu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (cboKhoa.SelectedIndex == -1 && string.IsNullOrWhiteSpace(cboKhoa.Text))
            {
                MessageBox.Show("Vui lòng chọn hoặc nhập Khoa/Lớp!", "Lỗi nhập liệu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cboKhoa.Focus();
                return;
            }
            string gioiTinh = radNam.Checked ? "Nam" : "Nữ";
            int tuoi = namHienTai - namSinh;
            string ketQua = "THÔNG TIN SINH VIÊN\r\n";
            ketQua += $"Họ tên: {txtHoTen.Text.Trim()}\r\n";
            ketQua += $"Tuổi: {tuoi}\r\n";
            ketQua += $"Email: {txtEmail.Text.Trim()}\r\n";
            ketQua += $"Giới tính: {gioiTinh}\r\n";
            ketQua += $"Khoa/Lớp: {cboKhoa.Text.Trim()}";
            txtKetQua.Text = ketQua;
        }
        private void BtnXoa_Click(object sender, EventArgs e)
        {
            txtHoTen.Clear();
            txtNamSinh.Clear();
            txtEmail.Clear();
            txtKetQua.Clear();
            radNam.Checked = false;
            radNu.Checked = false;
            cboKhoa.SelectedIndex = -1;
            cboKhoa.Text = "";
            txtHoTen.Focus();
        }
        private void BtnThoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn chắc chắn muốn thoát chương trình?", "Xác nhận thoát", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
        private void txtKetQua_TextChanged(object sender, EventArgs e)
        {
        }
        private void txtEmail_TextChanged(object sender, EventArgs e)
        {
        }

        private void txtNamSinh_TextChanged(object sender, EventArgs e)
        {

        }
    }
}