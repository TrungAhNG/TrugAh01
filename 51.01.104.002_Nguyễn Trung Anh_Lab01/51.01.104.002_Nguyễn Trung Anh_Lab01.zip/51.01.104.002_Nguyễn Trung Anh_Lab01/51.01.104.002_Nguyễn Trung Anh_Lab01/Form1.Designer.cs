﻿namespace _51._01._104._002_Nguyễn_Trung_Anh_Lab01
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTitle = new Label();
            txtHoTen = new TextBox();
            txtEmail = new TextBox();
            txtNamSinh = new TextBox();
            radNam = new RadioButton();
            radNu = new RadioButton();
            cboKhoa = new ComboBox();
            btnHienthi = new Button();
            btnXoa = new Button();
            btnThoat = new Button();
            txtKetQua = new TextBox();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Times New Roman", 10.2F);
            lblTitle.Location = new Point(12, 9);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(289, 19);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "Ứng dụng Thông tin cá nhân của Sinh viên";
            // 
            // txtHoTen
            // 
            txtHoTen.Font = new Font("Times New Roman", 10.2F);
            txtHoTen.Location = new Point(96, 35);
            txtHoTen.Name = "txtHoTen";
            txtHoTen.Size = new Size(125, 27);
            txtHoTen.TabIndex = 1;
            // 
            // txtEmail
            // 
            txtEmail.Font = new Font("Times New Roman", 10.2F);
            txtEmail.Location = new Point(96, 101);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(125, 27);
            txtEmail.TabIndex = 2;
            txtEmail.TextChanged += txtEmail_TextChanged;
            // 
            // txtNamSinh
            // 
            txtNamSinh.Font = new Font("Times New Roman", 10.2F);
            txtNamSinh.Location = new Point(96, 68);
            txtNamSinh.Name = "txtNamSinh";
            txtNamSinh.Size = new Size(125, 27);
            txtNamSinh.TabIndex = 3;
            txtNamSinh.TextChanged += txtNamSinh_TextChanged;
            // 
            // radNam
            // 
            radNam.AutoSize = true;
            radNam.Font = new Font("Times New Roman", 10.2F);
            radNam.Location = new Point(96, 134);
            radNam.Name = "radNam";
            radNam.Size = new Size(62, 23);
            radNam.TabIndex = 4;
            radNam.TabStop = true;
            radNam.Text = "Nam";
            radNam.UseVisualStyleBackColor = true;
            // 
            // radNu
            // 
            radNu.AutoSize = true;
            radNu.Font = new Font("Times New Roman", 10.2F);
            radNu.Location = new Point(170, 135);
            radNu.Name = "radNu";
            radNu.Size = new Size(51, 23);
            radNu.TabIndex = 5;
            radNu.TabStop = true;
            radNu.Text = "Nữ";
            radNu.UseVisualStyleBackColor = true;
            // 
            // cboKhoa
            // 
            cboKhoa.Font = new Font("Times New Roman", 10.2F);
            cboKhoa.FormattingEnabled = true;
            cboKhoa.Location = new Point(82, 162);
            cboKhoa.Name = "cboKhoa";
            cboKhoa.Size = new Size(151, 27);
            cboKhoa.TabIndex = 6;
            // 
            // btnHienthi
            // 
            btnHienthi.Font = new Font("Times New Roman", 10.2F);
            btnHienthi.Location = new Point(12, 195);
            btnHienthi.Name = "btnHienthi";
            btnHienthi.Size = new Size(94, 29);
            btnHienthi.TabIndex = 7;
            btnHienthi.Text = "Hiển thị";
            btnHienthi.UseVisualStyleBackColor = true;
            // 
            // btnXoa
            // 
            btnXoa.Font = new Font("Times New Roman", 10.2F);
            btnXoa.Location = new Point(112, 195);
            btnXoa.Name = "btnXoa";
            btnXoa.Size = new Size(94, 29);
            btnXoa.TabIndex = 8;
            btnXoa.Text = "Xóa";
            btnXoa.UseVisualStyleBackColor = true;
            // 
            // btnThoat
            // 
            btnThoat.Font = new Font("Times New Roman", 10.2F);
            btnThoat.Location = new Point(212, 195);
            btnThoat.Name = "btnThoat";
            btnThoat.Size = new Size(94, 29);
            btnThoat.TabIndex = 9;
            btnThoat.Text = "Thoát";
            btnThoat.UseVisualStyleBackColor = true;
            // 
            // txtKetQua
            // 
            txtKetQua.BackColor = Color.CornflowerBlue;
            txtKetQua.BorderStyle = BorderStyle.FixedSingle;
            txtKetQua.Font = new Font("Times New Roman", 10.2F);
            txtKetQua.Location = new Point(312, 28);
            txtKetQua.Multiline = true;
            txtKetQua.Name = "txtKetQua";
            txtKetQua.Size = new Size(294, 196);
            txtKetQua.TabIndex = 10;
            txtKetQua.TextChanged += txtKetQua_TextChanged;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(620, 240);
            Controls.Add(txtKetQua);
            Controls.Add(btnThoat);
            Controls.Add(btnXoa);
            Controls.Add(btnHienthi);
            Controls.Add(cboKhoa);
            Controls.Add(radNu);
            Controls.Add(radNam);
            Controls.Add(txtNamSinh);
            Controls.Add(txtEmail);
            Controls.Add(txtHoTen);
            Controls.Add(lblTitle);
            Name = "Form1";
            Text = "Ứng dụng nhập thông tin cá nhân";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTitle;
        private TextBox txtHoTen;
        private TextBox txtEmail;
        private TextBox txtNamSinh;
        private RadioButton radNam;
        private RadioButton radNu;
        private ComboBox cboKhoa;
        private Button btnHienthi;
        private Button btnXoa;
        private Button btnThoat;
        private TextBox txtKetQua;
    }
}
